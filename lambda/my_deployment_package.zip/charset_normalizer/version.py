"""
Expose version
"""

__version__ = "3.3.2"
VERSION = __version__.split(".")
